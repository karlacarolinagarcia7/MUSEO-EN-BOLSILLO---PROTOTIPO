import SwiftUI
import SwiftData

struct AjustesMuseoView: View {
    @Environment(\.dismiss) private var cerrar
    @Query private var favoritos: [PiezaFavorita]
    @Query private var vistas: [PiezaVista]
    @AppStorage(PreferenciasMuseo.apariencia) private var apariencia = 0

    @State private var conservarFavoritos = true
    @State private var confirmarReinicio = false

    var body: some View {
        Form {
            Section("Tu visita") {
                LabeledContent("Piezas vistas", value: "\(vistas.count) de \(CatalogoMuseo.piezas.count)")
                LabeledContent("Piezas favoritas", value: "\(favoritos.count)")
            }

            Section("Apariencia") {
                Picker("Tema", selection: $apariencia) {
                    Text("Sistema").tag(0)
                    Text("Claro").tag(1)
                    Text("Oscuro").tag(2)
                }
                .pickerStyle(.segmented)
            }

            Section {
                Toggle("Conservar mis favoritos", isOn: $conservarFavoritos)

                Button {
                    confirmarReinicio = true
                } label: {
                    Label("Preparar nueva demostración", systemImage: "arrow.counterclockwise")
                }
            } header: {
                Text("Reiniciar demostración")
            } footer: {
                Text("Al volver a abrir la app, los consejos se restablecerán y el avance volverá a cero. Puedes conservar tus favoritos o empezar sin ellos.")
            }

            Section("Acerca del museo") {
                Label("Museo en Bolsillo", systemImage: "building.columns.fill")
                Text("Prototipo educativo inspirado en la cultura salvadoreña. Las salas y las piezas son ficticias.")
                    .foregroundStyle(.secondary)
                Text("Los consejos aparecen según las acciones de tu visita y dejan de mostrarse cuando ya no son necesarios.")
                    .foregroundStyle(.secondary)
            }
        }
        .navigationTitle("Ajustes")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .topBarTrailing) {
                Button("Listo") { cerrar() }
            }
        }
        .confirmationDialog(
            "¿Preparar una nueva demostración?",
            isPresented: $confirmarReinicio,
            titleVisibility: .visible
        ) {
            Button("Preparar reinicio", role: .destructive) {
                ReinicioMuseo.preparar(conservarFavoritos: conservarFavoritos)
                cerrar()
            }
            Button("Cancelar", role: .cancel) { }
        } message: {
            Text(
                conservarFavoritos
                    ? "Al volver a abrir la app se borrará el avance y se restablecerán los consejos. Tus favoritos se conservarán."
                    : "Al volver a abrir la app se borrarán el avance y los favoritos, y se restablecerán los consejos."
            )
        }
    }
}
