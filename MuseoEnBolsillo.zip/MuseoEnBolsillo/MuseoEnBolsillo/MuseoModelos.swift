import SwiftUI
import SwiftData

// Cada registro representa una pieza guardada por el visitante.
@Model
final class PiezaFavorita {
    @Attribute(.unique) var piezaID: Int

    init(piezaID: Int) {
        self.piezaID = piezaID
    }
}

// Una pieza solo puede registrarse como vista una vez.
@Model
final class PiezaVista {
    @Attribute(.unique) var piezaID: Int

    init(piezaID: Int) {
        self.piezaID = piezaID
    }
}

struct PiezaMuseo: Identifiable {
    let id: Int
    let nombre: String
    let simbolo: String
    let descripcion: String
}

struct SalaMuseo: Identifiable {
    let id: Int
    let nombre: String
    let subtitulo: String
    let simbolo: String
    let color: Color
    let piezas: [PiezaMuseo]
}

// Catálogo ficticio: no representa piezas de un museo real.
enum CatalogoMuseo {
    static let salas: [SalaMuseo] = [
        SalaMuseo(
            id: 1, nombre: "Raíces",
            subtitulo: "Objetos que cuentan historias",
            simbolo: "leaf.fill", color: .teal,
            piezas: [
                PiezaMuseo(
                    id: 101, nombre: "Vasija de los caminos",
                    simbolo: "cup.and.saucer.fill",
                    descripcion: "Una vasija imaginaria con líneas que evocan caminos. Observa sus formas y piensa qué historia contarías con ellas."
                ),
                PiezaMuseo(
                    id: 102, nombre: "Cuenco de la tierra",
                    simbolo: "bowl.fill",
                    descripcion: "Un cuenco ficticio inspirado en los tonos de la tierra. Sus detalles invitan a observar cómo un objeto cotidiano puede convertirse en una expresión creativa."
                )
            ]
        ),
        SalaMuseo(
            id: 2, nombre: "Memoria",
            subtitulo: "Un encuentro con el pasado",
            simbolo: "clock.fill", color: .orange,
            piezas: [
                PiezaMuseo(
                    id: 201, nombre: "La plaza de los recuerdos",
                    simbolo: "photo.fill",
                    descripcion: "Una fotografía imaginaria de una plaza. Piensa en un lugar de tu comunidad que conservarías en una fotografía y en las personas que lo hacen especial."
                ),
                PiezaMuseo(
                    id: 202, nombre: "Carta a mi comunidad",
                    simbolo: "envelope.fill",
                    descripcion: "Una carta ficticia dedicada a los recuerdos de una comunidad. ¿Qué experiencia de tu vida te gustaría que conocieran las próximas generaciones?"
                )
            ]
        ),
        SalaMuseo(
            id: 3, nombre: "Expresiones",
            subtitulo: "Creatividad e identidad",
            simbolo: "paintpalette.fill", color: .purple,
            piezas: [
                PiezaMuseo(
                    id: 301, nombre: "Colores de mi pueblo",
                    simbolo: "paintpalette.fill",
                    descripcion: "Una pintura imaginaria que reúne colores asociados con la vida de un pueblo. ¿Qué colores elegirías para representar el lugar donde vives?"
                ),
                PiezaMuseo(
                    id: 302, nombre: "Tejido de encuentros",
                    simbolo: "square.grid.3x3.fill",
                    descripcion: "Un tejido ficticio de figuras que se conectan. Cada figura representa, dentro de esta propuesta artística, una experiencia compartida con otras personas."
                )
            ]
        )
    ]

    static var piezas: [PiezaMuseo] {
        salas.flatMap { $0.piezas }
    }
}

