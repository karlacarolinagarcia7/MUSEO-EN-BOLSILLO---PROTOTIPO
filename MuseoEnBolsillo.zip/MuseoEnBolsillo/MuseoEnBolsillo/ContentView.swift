import SwiftUI
import SwiftData
import TipKit

struct ContentView: View {
    @Query private var favoritos: [PiezaFavorita]
    @Query private var vistas: [PiezaVista]
    @State private var mostrarColeccion = false
    @State private var mostrarPlano = false
    @State private var mostrarAjustes = false

    private let consejoSala = ElegirSalaTip()
    private let consejoColeccion = ColeccionTip()
    private let consejoPlano = PlanoTip()

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 24) {
                    Label("Descubre nuestra cultura", systemImage: "building.columns.fill")
                        .font(.title2.bold())
                        .foregroundStyle(.teal)

                    presentacion

                    Button {
                        ocultarConsejosInicio()
                        mostrarAjustes = true
                    } label: {
                        Label("Ajustes", systemImage: "gearshape")
                    }
                    .buttonStyle(.bordered)

                    progresoVisita

                    VStack(alignment: .leading, spacing: 8) {
                        Text("Tu visita comienza aquí")
                            .font(.title2.bold())
                        Text("Tres salas. Seis piezas por descubrir.")
                            .foregroundStyle(.secondary)
                    }

                    TipView(consejoSala, arrowEdge: .bottom)
                        .tint(.teal)

                    ForEach(CatalogoMuseo.salas) { sala in
                        NavigationLink {
                            DetalleSalaView(sala: sala)
                        } label: {
                            TarjetaSalaView(sala: sala)
                        }
                        .buttonStyle(.plain)
                    }

                    Text("Museo ficticio con fines educativos. Las piezas y sus símbolos son contenido de demostración.")
                        .font(.footnote)
                        .foregroundStyle(.secondary)
                }
                .padding(20)
            }
            .background(Color(.systemGroupedBackground))
            .navigationTitle("Museo en Bolsillo")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarLeading) {
                    Button {
                        // El plano está disponible desde el principio.
                        // Se da el consejo por aprendido si ya era relevante.
                        if vistas.count >= 2 {
                            consejoPlano.invalidate(reason: .actionPerformed)
                        }
                        ocultarConsejosInicio()
                        mostrarPlano = true
                    } label: {
                        Image(systemName: "map.fill")
                    }
                    .buttonStyle(.plain)
                    .accessibilityLabel("Plano del museo")
                    .popoverTip(consejoPlano)
                }
                ToolbarItem(placement: .topBarTrailing) {
                    Button {
                        // Abrir una colección vacía no da el consejo por aprendido.
                        if !favoritos.isEmpty {
                            consejoColeccion.invalidate(reason: .actionPerformed)
                        }
                        ocultarConsejosInicio()
                        mostrarColeccion = true
                    } label: {
                        Image(systemName: "heart.fill")
                    }
                    // Estilo explícito para el consejo anclado a la barra superior.
                    .buttonStyle(.plain)
                    .accessibilityLabel("Mi colección")
                    .popoverTip(consejoColeccion)
                }
            }
            .onAppear(perform: activarConsejosInicio)
            .onDisappear(perform: ocultarConsejosInicio)
            .onChange(of: favoritos.count) { _, cantidad in
                ColeccionTip.tieneFavoritos = cantidad > 0
            }
            .sheet(isPresented: $mostrarColeccion, onDismiss: activarConsejosInicio) {
                NavigationStack {
                    ColeccionView()
                }
                .tint(.teal)
            }
            .sheet(isPresented: $mostrarPlano, onDismiss: activarConsejosInicio) {
                NavigationStack {
                    PlanoMuseoView()
                }
                .tint(.teal)
            }
            .sheet(isPresented: $mostrarAjustes, onDismiss: activarConsejosInicio) {
                NavigationStack {
                    AjustesMuseoView()
                }
                .tint(.teal)
            }
        }
        .tint(.teal)
    }

    private func activarConsejosInicio() {
        ColeccionTip.tieneFavoritos = !favoritos.isEmpty
        ColeccionTip.estaEnInicio = true
        PlanoTip.estaEnInicio = true
    }

    private func ocultarConsejosInicio() {
        ColeccionTip.estaEnInicio = false
        PlanoTip.estaEnInicio = false
    }

    private var progresoVisita: some View {
        VStack(alignment: .leading, spacing: 12) {
            Label("Tu recorrido", systemImage: "figure.walk")
                .font(.headline)
            Text("\(vistas.count) de \(CatalogoMuseo.piezas.count) piezas vistas")
                .foregroundStyle(.secondary)
            ProgressView(
                value: Double(vistas.count),
                total: Double(CatalogoMuseo.piezas.count)
            )
            .tint(.teal)
            if vistas.count == CatalogoMuseo.piezas.count {
                Text("¡Completaste el recorrido!")
                    .font(.subheadline.bold())
                    .foregroundStyle(.teal)
            }
        }
        .padding(20)
        .background(
            Color(.secondarySystemGroupedBackground),
            in: RoundedRectangle(cornerRadius: 22)
        )
    }

    private var presentacion: some View {
        VStack(alignment: .leading, spacing: 16) {
            Image(systemName: "building.columns")
                .font(.system(size: 46))
                .accessibilityHidden(true)
            Text("Cada pieza tiene\nalgo que contarte.")
                .font(.largeTitle.bold())
            Text("Explora un museo inspirado en la cultura salvadoreña, a tu propio ritmo.")
        }
        .foregroundStyle(.white)
        .padding(24)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(
            LinearGradient(
                colors: [
                    Color(red: 0.05, green: 0.36, blue: 0.35),
                    Color(red: 0.08, green: 0.53, blue: 0.48)
                ],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            ),
            in: RoundedRectangle(cornerRadius: 26)
        )
    }
}

private struct TarjetaSalaView: View {
    let sala: SalaMuseo

    var body: some View {
        HStack(spacing: 16) {
            Image(systemName: sala.simbolo)
                .font(.title2)
                .foregroundStyle(sala.color)
                .frame(width: 58, height: 58)
                .background(sala.color.opacity(0.12), in: RoundedRectangle(cornerRadius: 16))
                .accessibilityHidden(true)
            VStack(alignment: .leading, spacing: 5) {
                Text(sala.nombre).font(.headline)
                Text(sala.subtitulo)
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
                Text("\(sala.piezas.count) piezas")
                    .font(.caption)
                    .foregroundStyle(sala.color)
            }
            Spacer(minLength: 0)
            Image(systemName: "chevron.right")
                .foregroundStyle(.secondary)
                .accessibilityHidden(true)
        }
        .padding(16)
        .background(Color(.secondarySystemGroupedBackground), in: RoundedRectangle(cornerRadius: 22))
    }
}

struct DetalleSalaView: View {
    let sala: SalaMuseo

    var body: some View {
        List {
            Section {
                Label(sala.subtitulo, systemImage: sala.simbolo)
                    .foregroundStyle(sala.color)
                    .padding(.vertical, 12)
            }
            Section("Piezas de esta sala") {
                ForEach(sala.piezas) { pieza in
                    NavigationLink {
                        DetallePiezaView(pieza: pieza)
                    } label: {
                        FilaPiezaView(pieza: pieza)
                    }
                }
            }
        }
        .navigationTitle(sala.nombre)
        .onAppear {
            ElegirSalaTip().invalidate(reason: .actionPerformed)
        }
    }
}

private struct FilaPiezaView: View {
    let pieza: PiezaMuseo
    @Query private var vistas: [PiezaVista]

    var body: some View {
        HStack(spacing: 14) {
            Image(systemName: pieza.simbolo)
                .font(.title2)
                .foregroundStyle(.teal)
                .frame(width: 42)
                .accessibilityHidden(true)
            VStack(alignment: .leading, spacing: 4) {
                Text(pieza.nombre).font(.headline)
                Text("Ver pieza")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
            Spacer(minLength: 0)
            if vistas.contains(where: { $0.piezaID == pieza.id }) {
                Image(systemName: "checkmark.circle.fill")
                    .foregroundStyle(.teal)
                    .accessibilityLabel("Pieza vista")
            }
        }
        .padding(.vertical, 8)
    }
}

private struct DetallePiezaView: View {
    let pieza: PiezaMuseo

    @Environment(\.modelContext) private var contexto
    @Query private var favoritos: [PiezaFavorita]
    @Query private var vistas: [PiezaVista]
    @State private var mostrarError = false
    @State private var registrandoVista = false
    @State private var vistaRegistradaAhora = false

    private var esFavorita: Bool {
        favoritos.contains { $0.piezaID == pieza.id }
    }

    private var yaVista: Bool {
        vistaRegistradaAhora || vistas.contains { $0.piezaID == pieza.id }
    }

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 24) {
                Image(systemName: pieza.simbolo)
                    .font(.system(size: 80))
                    .foregroundStyle(.teal)
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 45)
                    .background(.teal.opacity(0.12), in: RoundedRectangle(cornerRadius: 26))
                    .accessibilityHidden(true)

                Text(pieza.nombre).font(.largeTitle.bold())
                Text("PIEZA DE DEMOSTRACIÓN")
                    .font(.caption.bold())
                    .foregroundStyle(.secondary)
                Text(pieza.descripcion)
                    .font(.body)

                Button {
                    Task {
                        await marcarComoVista()
                    }
                } label: {
                    Label(
                        registrandoVista ? "Registrando..." :
                            (yaVista ? "Pieza marcada como vista" : "Marcar como vista"),
                        systemImage: yaVista ? "checkmark.circle.fill" : "eye"
                    )
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 8)
                }
                .buttonStyle(.bordered)
                .disabled(yaVista || registrandoVista)

                Button(action: cambiarFavorito) {
                    Label(
                        esFavorita ? "Quitar de mi colección" : "Guardar en mi colección",
                        systemImage: esFavorita ? "heart.fill" : "heart"
                    )
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 8)
                }
                .buttonStyle(.borderedProminent)
                .disabled(registrandoVista)
            }
            .padding(20)
        }
        .navigationTitle("Detalle de pieza")
        .navigationBarTitleDisplayMode(.inline)
        .alert("No se pudo guardar el cambio", isPresented: $mostrarError) {
            Button("Aceptar", role: .cancel) { }
        } message: {
            Text("Inténtalo nuevamente. El cambio no se guardó.")
        }
    }

    private func marcarComoVista() async {
        guard !yaVista && !registrandoVista else { return }
        registrandoVista = true
        defer { registrandoVista = false }

        contexto.insert(PiezaVista(piezaID: pieza.id))
        do {
            try contexto.save()
        } catch {
            contexto.rollback()
            mostrarError = true
            return
        }

        // Un aporte por pieza distinta; reabrirla no suma eventos.
        vistaRegistradaAhora = true
        await PlanoTip.piezaVista.donate()
    }

    private func cambiarFavorito() {
        if let favorito = favoritos.first(where: { $0.piezaID == pieza.id }) {
            contexto.delete(favorito)
        } else {
            contexto.insert(PiezaFavorita(piezaID: pieza.id))
        }

        do {
            try contexto.save()
        } catch {
            contexto.rollback()
            mostrarError = true
        }
    }
}

private struct ColeccionView: View {
    @Environment(\.dismiss) private var cerrar
    @Query private var favoritos: [PiezaFavorita]

    private var piezasGuardadas: [PiezaMuseo] {
        CatalogoMuseo.piezas.filter { pieza in
            favoritos.contains { $0.piezaID == pieza.id }
        }
    }

    var body: some View {
        Group {
            if piezasGuardadas.isEmpty {
                ContentUnavailableView(
                    "Tu colección está vacía",
                    systemImage: "heart",
                    description: Text("Entra a una sala y guarda una pieza que te guste.")
                )
            } else {
                List(piezasGuardadas) { pieza in
                    NavigationLink {
                        DetallePiezaView(pieza: pieza)
                    } label: {
                        FilaPiezaView(pieza: pieza)
                    }
                }
            }
        }
        .navigationTitle("Mi colección")
        .toolbar {
            ToolbarItem(placement: .topBarTrailing) {
                Button("Listo") { cerrar() }
            }
        }
    }
}

