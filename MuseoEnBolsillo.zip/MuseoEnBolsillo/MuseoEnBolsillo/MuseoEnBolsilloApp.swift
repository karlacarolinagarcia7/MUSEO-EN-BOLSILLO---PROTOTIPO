//
//  MuseoEnBolsilloApp.swift
//  MuseoEnBolsillo
//
//  Created by Usuario invitado on 1/11/26.
//

import SwiftUI
import SwiftData
import TipKit

@main
struct MuseoEnBolsilloApp: App {
    private let contenedor: ModelContainer?
    private let mensajeError: String?

    init() {
        do {
            let nuevoContenedor = try ModelContainer(
                for: PiezaFavorita.self, PiezaVista.self
            )

            // El reinicio se aplica solo si fue preparado desde Ajustes.
            // Debe completarse antes de configurar TipKit y mostrar vistas.
            try ReinicioMuseo.aplicarSiPendiente(
                contexto: nuevoContenedor.mainContext
            )
            try Tips.configure([.displayFrequency(.immediate)])

            contenedor = nuevoContenedor
            mensajeError = nil
        } catch {
            contenedor = nil
            mensajeError = error.localizedDescription
            print("No se pudo iniciar el museo: \(error.localizedDescription)")
        }
    }

    var body: some Scene {
        WindowGroup {
            if let contenedor {
                RaizMuseoView()
                    .modelContainer(contenedor)
            } else {
                ContentUnavailableView {
                    Label("No se pudo iniciar el museo", systemImage: "exclamationmark.triangle")
                } description: {
                    Text(mensajeError ?? "Cierra la app y vuelve a intentarlo.")
                }
            }
        }
    }
}
