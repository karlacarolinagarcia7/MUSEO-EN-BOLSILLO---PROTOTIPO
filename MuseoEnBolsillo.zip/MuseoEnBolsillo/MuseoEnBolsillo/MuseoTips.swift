//
//  MuseoTips.swift
//  MuseoEnBolsillo
//
//  Created by Usuario invitado on 1/11/26.
//

import SwiftUI
import TipKit

struct ElegirSalaTip: Tip {
    var title: Text { Text("Elige tu propio recorrido") }
    var message: Text? {
        Text("Puedes visitar las salas en cualquier orden. Toca una tarjeta para conocer sus piezas.")
    }
    var image: Image? { Image(systemName: "sparkles") }
    var options: [Option] { MaxDisplayCount(1) }
}

struct ColeccionTip: Tip {
    // Nueva identidad para probar la corrección sin reiniciar otros consejos.
    var id: String { "museo.coleccion.v2" }

    @Parameter static var tieneFavoritos: Bool = false
    @Parameter static var estaEnInicio: Bool = false

    var title: Text { Text("Tu colección ya comenzó") }
    var message: Text? {
        Text("Toca este corazón para encontrar las piezas que guardaste.")
    }
    var image: Image? { Image(systemName: "heart.fill") }

    var rules: [Rule] {
        #Rule(Self.$tieneFavoritos) { $0 == true }
        #Rule(Self.$estaEnInicio) { $0 == true }
    }

    var options: [Option] { MaxDisplayCount(1) }
}

struct PlanoTip: Tip {
    // Cada primera marca de una pieza distinta aporta un evento.
    static let piezaVista: Event = Event(id: "museo.piezaVista.v1")

    @Parameter static var estaEnInicio: Bool = false

    var title: Text { Text("Ya descubriste dos piezas") }
    var message: Text? {
        Text("Abre el plano para ubicar las salas y elegir dónde continuar tu visita.")
    }
    var image: Image? { Image(systemName: "map.fill") }

    var rules: [Rule] {
        #Rule(Self.piezaVista) { $0.donations.count >= 2 }
        #Rule(Self.$estaEnInicio) { $0 == true }
    }

    var options: [Option] { MaxDisplayCount(1) }
}
