import SwiftUI
import SwiftData
import TipKit

// Claves compartidas entre Ajustes y el arranque de la app.
enum PreferenciasMuseo {
    static let apariencia = "museo.apariencia"
    static let reinicioPendiente = "museo.reinicioPendiente"
    static let conservarFavoritos = "museo.conservarFavoritosAlReiniciar"
}

@MainActor
enum ReinicioMuseo {
    static func preparar(conservarFavoritos: Bool) {
        let preferencias = UserDefaults.standard
        preferencias.set(conservarFavoritos, forKey: PreferenciasMuseo.conservarFavoritos)
        preferencias.set(true, forKey: PreferenciasMuseo.reinicioPendiente)
    }

    static func cancelar() {
        let preferencias = UserDefaults.standard
        preferencias.removeObject(forKey: PreferenciasMuseo.reinicioPendiente)
        preferencias.removeObject(forKey: PreferenciasMuseo.conservarFavoritos)
    }

    // Se llama únicamente al arrancar, antes de Tips.configure().
    static func aplicarSiPendiente(contexto: ModelContext) throws {
        let preferencias = UserDefaults.standard
        guard preferencias.bool(forKey: PreferenciasMuseo.reinicioPendiente) else {
            return
        }

        // Si falta la preferencia, conservamos los favoritos por defecto.
        let conservar = preferencias.object(
            forKey: PreferenciasMuseo.conservarFavoritos
        ) as? Bool ?? true

        let vistas = try contexto.fetch(FetchDescriptor<PiezaVista>())
        var favoritos: [PiezaFavorita] = []
        if !conservar {
            favoritos = try contexto.fetch(FetchDescriptor<PiezaFavorita>())
        }

        // Restablece consejos, parámetros y eventos, antes de configurar TipKit.
        try Tips.resetDatastore()

        for vista in vistas {
            contexto.delete(vista)
        }
        for favorito in favoritos {
            contexto.delete(favorito)
        }

        do {
            try contexto.save()
        } catch {
            contexto.rollback()
            // Dejamos la solicitud pendiente para reintentar al arrancar.
            throw error
        }

        preferencias.removeObject(forKey: PreferenciasMuseo.reinicioPendiente)
        preferencias.removeObject(forKey: PreferenciasMuseo.conservarFavoritos)
    }
}

// Aplica la apariencia y evita continuar la visita con un reinicio pendiente.
struct RaizMuseoView: View {
    @AppStorage(PreferenciasMuseo.apariencia) private var apariencia = 0
    @AppStorage(PreferenciasMuseo.reinicioPendiente) private var reinicioPendiente = false

    private var esquema: ColorScheme? {
        switch apariencia {
        case 1: return .light
        case 2: return .dark
        default: return nil
        }
    }

    var body: some View {
        Group {
            if reinicioPendiente {
                ReinicioPendienteView()
            } else {
                ContentView()
            }
        }
        .preferredColorScheme(esquema)
        .tint(.teal)
    }
}

private struct ReinicioPendienteView: View {
    @AppStorage(PreferenciasMuseo.conservarFavoritos) private var conservarFavoritos = true

    var body: some View {
        ScrollView {
            VStack(spacing: 24) {
                Image(systemName: "arrow.counterclockwise.circle.fill")
                    .font(.system(size: 72))
                    .foregroundStyle(.teal)
                    .accessibilityHidden(true)

                Text("Demostración preparada")
                    .font(.largeTitle.bold())

                Text("Cierra la app por completo y vuelve a abrirla para comenzar una nueva demostración.")
                    .foregroundStyle(.secondary)

                VStack(alignment: .leading, spacing: 14) {
                    Label("Los consejos podrán aparecer otra vez", systemImage: "sparkles")
                    Label("El avance volverá a 0 de 6", systemImage: "eye")
                    Label(
                        conservarFavoritos ? "Tus favoritos se conservarán" : "Se borrarán tus favoritos",
                        systemImage: conservarFavoritos ? "heart.fill" : "heart.slash"
                    )
                }
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding(20)
                .background(Color(.secondarySystemGroupedBackground), in: RoundedRectangle(cornerRadius: 22))

                Text("Los cambios se aplicarán al volver a abrir la app.")
                    .font(.footnote)
                    .foregroundStyle(.secondary)

                Button("Cancelar reinicio y volver al museo") {
                    ReinicioMuseo.cancelar()
                }
                .buttonStyle(.bordered)
            }
            .multilineTextAlignment(.center)
            .padding(24)
            .padding(.top, 40)
        }
        .background(Color(.systemGroupedBackground))
    }
}
