import SwiftUI
import SwiftData

struct PlanoMuseoView: View {
    @Environment(\.dismiss) private var cerrar
    @Query private var vistas: [PiezaVista]

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 24) {
                Text("Elige tu siguiente sala")
                    .font(.title2.bold())
                Text("Toca una zona para entrar. Cada sala muestra cuántas de sus piezas has visto.")
                    .foregroundStyle(.secondary)

                VStack(spacing: 16) {
                    Label("Entrada", systemImage: "door.left.hand.open")
                        .font(.headline)
                        .padding(.vertical, 8)

                    HStack(alignment: .top, spacing: 14) {
                        ForEach(CatalogoMuseo.salas.prefix(2)) { sala in
                            zona(sala)
                        }
                    }

                    Label("Pasillo central", systemImage: "figure.walk")
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 12)
                        .background(.teal.opacity(0.08), in: RoundedRectangle(cornerRadius: 12))

                    if let sala = CatalogoMuseo.salas.last {
                        zona(sala)
                    }

                    Label("Salida", systemImage: "door.right.hand.open")
                        .font(.headline)
                        .padding(.vertical, 8)
                }
                .padding(16)
                .background(
                    Color(.secondarySystemGroupedBackground),
                    in: RoundedRectangle(cornerRadius: 24)
                )

                Text("Plano ilustrado de un museo ficticio. No está a escala.")
                    .font(.footnote)
                    .foregroundStyle(.secondary)
            }
            .padding(20)
        }
        .background(Color(.systemGroupedBackground))
        .navigationTitle("Plano del museo")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .topBarTrailing) {
                Button("Listo") { cerrar() }
            }
        }
    }

    private func zona(_ sala: SalaMuseo) -> some View {
        let cantidad = sala.piezas.filter { pieza in
            vistas.contains { $0.piezaID == pieza.id }
        }.count

        return NavigationLink {
            DetalleSalaView(sala: sala)
        } label: {
            VStack(spacing: 12) {
                Image(systemName: sala.simbolo)
                    .font(.largeTitle)
                    .accessibilityHidden(true)
                Text(sala.nombre)
                    .font(.headline)
                Text("\(cantidad)/\(sala.piezas.count) vistas")
                    .font(.subheadline)
                Label("Entrar", systemImage: "arrow.right")
                    .font(.caption.bold())
            }
            .foregroundStyle(sala.color)
            .padding(16)
            .frame(maxWidth: .infinity, minHeight: 150)
            .background(sala.color.opacity(0.10), in: RoundedRectangle(cornerRadius: 18))
            .overlay {
                RoundedRectangle(cornerRadius: 18)
                    .stroke(sala.color.opacity(0.4), lineWidth: 2)
            }
        }
        .buttonStyle(.plain)
        .accessibilityLabel("Sala \(sala.nombre), \(cantidad) de \(sala.piezas.count) piezas vistas. Entrar.")
    }
}
